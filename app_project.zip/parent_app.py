cat << 'EOF' > parent_app.py
import time
import firebase_admin
from firebase_admin import credentials, db

def init_firebase():
    if not firebase_admin._apps:
        try:
            cred = credentials.Certificate('serviceAccountKey.json')
            firebase_admin.initialize_app(cred, {
                'databaseURL': 'https://parentalcontrol-3a591-default-rtdb.firebaseio.com/'
            })
            return True
        except Exception as e:
            print(f"❌ خطأ الفايربيس: {e}")
            return False
    return True

def control_panel():
    while True:
        print("\n" + "="*50)
        print("👑 [ لوحة تحكم الأب الملكية - التحكم الكامل ] 👑")
        print("="*50)
        print("1. 📱 عرض قائمة الأطفال والحالة الحية")
        print("2. ⚠️ إرسال أمر فورمات (Format/تهيئة) لجهاز الطفل")
        print("3. 🔄 تحديث القائمة")
        print("4. 🚪 خروج")
        
        choice = input("\nاختر رقم الأمر: ").strip()
        
        if choice == '1':
            children = db.reference('children').get()
            if children:
                print("\n--- قائمة الأجهزة المربوطة ---")
                for cid, cinfo in children.items():
                    print(f"🔹 ID: {cid} | الاسم: {cinfo.get('name')} | الحالة: {cinfo.get('status')} | آخر ظهور: {cinfo.get('last_seen')}")
            else:
                print("\n❌ لا يوجد أطفال مربوطين حالياً.")
                
        elif choice == '2':
            child_id = input("أدخل ID جهاز الطفل المراد فرمتته (مثال child_device_01): ").strip()
            if child_id:
                db.reference(f'children/{child_id}').update({'command': 'format'})
                print(f"⚡ تم إرسال أمر الفرمتة إلى الجهاز {child_id} بنجاح!")
                
        elif choice == '3':
            print("🔄 تم تحديث البيانات.")
        elif choice == '4':
            print("👋 تم الخروج من اللوحة.")
            break

def main():
    if not init_firebase():
        return

    print("📜 [ شروط الاستخدام والقوانين ]")
    print("1. التطبيق للاستخدام الأبوي فقط.")
    print("2. يمنع الاستخدام غير الشرعي.")
    
    agree = input("\nهل توافق على الشروط؟ (y/n): ").strip().lower()
    if agree != 'y':
        print("❌ تم إلغاء العملية لعدم الموافقة.")
        return

    print("\n⏳ جاري تجهيز النظام...")
    for i in range(5, 0, -1):
        print(f"انتظر... {i}")
        time.sleep(1)

    key = input("\n🔑 أدخل كود التفعيل VIP: ").strip()
    key_ref = db.reference(f'keys/{key}')
    key_data = key_ref.get()

    if key_data and key_data.get('status') == 'active':
        print("\n🎉 تم التفعيل بنجاح! جاري فتح لوحة التحكم...")
        key_ref.update({'status': 'used'})
        control_panel()
    else:
        print("\n❌ كود التفعيل غير صحيح أو تم استخدامه من قبل!")

if __name__ == '__main__':
    main()
EOF

