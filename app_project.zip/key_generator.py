import time
import random
import string
import firebase_admin
from firebase_admin import credentials, db

def init_firebase():
    if not firebase_admin._apps:
        try:
            cred = credentials.Certificate('serviceAccountKey.json')
            firebase_admin.initialize_app(cred, {
                'databaseURL': 'https://parentalcontrol-3a591-default-rtdb.firebaseio.com/'
            })
            print("✅ تم الاتصال بالفايربيس بنجاح!")
        except Exception as e:
            print(f"❌ خطأ في ملف الاتصال: {e}")
            return False
    return True

def generate_key():
    if not init_firebase():
        return

    print("\n" + "="*45)
    print("👑 [مولد الأكواد الملكي - رفع مباشر للسيرفر]")
    print("="*45)

    custom_key = input("أدخل الكود المخصص (أو اضغط Enter لتوليد تلقائي): ").strip()
    if not custom_key:
        random_suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        license_key = f"AYMAN-VIP-{random_suffix}"
    else:
        license_key = custom_key

    days_input = input("أدخل عدد أيام التفعيل (الافتراضي 30): ").strip()
    days = int(days_input) if days_input.isdigit() else 30

    key_data = {
        'status': 'active',
        'duration_days': days,
        'created_at': time.strftime("%Y-%m-%d %H:%M:%S"),
        'developer': 'https://t.me/Aimng'
    }

    db.reference(f'keys/{license_key}').set(key_data)

    print("\n" + "="*45)
    print(f"🎉 تم توليد الكود ورفعه بنجاح!")
    print(f"🔑 الكود: {license_key}")
    print(f"⏱️ المدة: {days} يوم")
    print("="*45 + "\n")

if __name__ == '__main__':
    generate_key()
