cat << 'EOF' > child_app.py
import time
import firebase_admin
from firebase_admin import credentials, db

def init_firebase():
    if not firebase_admin._apps:
        try:
            cred = credentials.Certificate('serviceAccountKey.json')
            firebase_admin.initialize_app(cred, {
                'databaseURL': 'https://parentalcontrol-3a591-default-rtdb.firebaseio.com/'
            })
        except Exception as e:
            print(f"❌ خطأ اتصال الطفل: {e}")

def run_child_service():
    init_firebase()
    print("="*50)
    print("👶 [تطبيق الطفل - يعمل في الخلفية ويستقبل الأوامر]")
    print("="*50)
    
    child_id = "child_device_01"
    ref = db.reference(f'children/{child_id}')
    
    while True:
        current_time = time.strftime("%Y-%m-%d %H:%M:%S")
        
        # قراءة الأوامر القادمة من الأب
        data = ref.get() or {}
        command = data.get('command', 'none')
        
        if command == 'format':
            print("\n⚠️ [تنبيه عاجل]: تم استقبال أمر الفرمتة/التهيئة من الأب!")
            print("🚨 جاري تنفيذ إزالة البيانات وإعادة ضبط المصنع للطفل...")
            ref.update({'command': 'formatted', 'status': 'تمت الفرمتة ⚠️'})
        
        ref.update({
            'name': 'هاتف الطفل (أيمن)',
            'status': 'متصل 🟢' if command != 'formatted' else 'تمت الفرمتة ⚠️',
            'last_seen': current_time
        })
        
        print(f"📡 إرسال إشارة الحياة: {current_time} | الأمر الحالي: {command}")
        time.sleep(10)

if __name__ == '__main__':
    run_child_service()
EOF

